const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send('Welcome to bookhub!');
});

const logger = (req, res, next) => {
    console.log('Passing through logger')
    next();
}

const authenticate = (req, res, next) => {
    const user = req.params.user;
    if (user == undefined) {
        res.status(401).send('Un-authorized request');
    } else {
        next();
    }
    console.log('Passing through logger')
}

app.use(logger)

const bookHub = []

app.post('/cart/add', (req, res) => {
    book = req.body;
    bookHub.push(req.body)
    res.send(`${book.name} added to cart`)
});

app.delete('/cart/remove/:id', (req, res) => {
    const id = req.params.id;
    const book = bookHub[id];
    bookHub.splice(id, 1);
    res.send(`${book.name} removed from cart`);
});

app.listen(3000,() => {console.log('')})