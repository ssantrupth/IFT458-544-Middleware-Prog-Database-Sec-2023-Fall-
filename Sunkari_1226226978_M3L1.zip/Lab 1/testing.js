let math = require('./mathModule.js');

console.log(math.add(9,8));
console.log(math.subtract(9,8));
console.log(math.multiply(9,8));
console.log(math.divide(9,8));
