{
    let blockLevelVariable = "Block Level";
    //This is a block level variable
    console.log(blockLevelVariable);
    // Prints "Block Level"
}

console.log(blockLevelVariable);
