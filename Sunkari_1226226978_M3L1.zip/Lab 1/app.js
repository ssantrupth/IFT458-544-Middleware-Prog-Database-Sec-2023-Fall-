// main.js

// Using the require function to import the rectangle module
const rectangle = require('./node');

// Calculating the area of a rectangle
const length = 5;
const width = 3;
const area = rectangle.calculateArea(length, width);

console.log(`The area of the rectangle with length ${length} and width ${width} is ${area}`);
