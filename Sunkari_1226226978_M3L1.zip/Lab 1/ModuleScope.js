let moduleLevelVariable = "Module Level";
// This is a module level variable

function displayVar() {
    console.log(moduleLevelVariable);
}

displayVar();